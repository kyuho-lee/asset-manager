// Profile Feature
export function initProfile() { console.log('✅ Profile 초기화'); }
