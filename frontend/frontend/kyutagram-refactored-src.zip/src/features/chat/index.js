// Chat Feature
export function initChat() { console.log('✅ Chat 초기화'); }
