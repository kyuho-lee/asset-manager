// ========== Auth Feature Entry Point ==========
// TODO: main.js에서 인증 관련 코드 이동

export function initAuth() {
    console.log('✅ Auth 모듈 초기화');
    // TODO: 로그인/회원가입 초기화
}

export function showLoginModal() {
    // TODO: 로그인 모달 표시
}

export function showSignupModal() {
    // TODO: 회원가입 모달 표시
}

export function logout() {
    // TODO: 로그아웃 처리
}
