// Comments Feature
export function initComments() { console.log('✅ Comments 초기화'); }
